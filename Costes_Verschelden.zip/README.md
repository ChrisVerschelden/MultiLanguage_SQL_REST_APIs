# MultiLanguage_SQL_REST_APIs
multiple versions of a REST API for a SQL database. All APIs are contained in a docker containers, paired in a docker compose with a mariadb database and an adminer instance (both of which are contained in docker containers themselves) 
